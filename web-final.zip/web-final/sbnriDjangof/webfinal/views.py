from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return render(request, 'webfinal.html')


def index(request):
    return render(request, 'index.html')

def tryp(request):
    return render(request, 'tryp.html')

def integrate(request):
    return render(request, 'integratedmodules.html')