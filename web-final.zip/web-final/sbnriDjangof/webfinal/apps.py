from django.apps import AppConfig


class WebfinalConfig(AppConfig):
    name = 'webfinal'
